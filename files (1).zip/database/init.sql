-- users
CREATE TABLE IF NOT EXISTS users(
  id SERIAL PRIMARY KEY,
  email TEXT UNIQUE NOT NULL,
  password_hash TEXT,
  role TEXT DEFAULT 'user',
  created_at TIMESTAMP DEFAULT NOW()
);

-- orders
CREATE TABLE IF NOT EXISTS orders(
  id SERIAL PRIMARY KEY,
  user_id INTEGER REFERENCES users(id),
  provider_order_id TEXT,
  total_amount BIGINT,
  currency TEXT,
  status TEXT,
  created_at TIMESTAMP DEFAULT NOW()
);

-- analytics_events
CREATE TABLE IF NOT EXISTS analytics_events(
  id SERIAL PRIMARY KEY,
  type TEXT NOT NULL,
  user_id INTEGER,
  product_id TEXT,
  session_id TEXT,
  meta JSONB,
  created_at TIMESTAMP DEFAULT NOW()
);