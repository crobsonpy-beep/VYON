from fastapi import FastAPI
from pydantic import BaseModel
app = FastAPI()

class ConversationRequest(BaseModel):
    user_id: int
    message: str
    context: dict = {}

@app.post("/chat")
def chat(req: ConversationRequest):
    # Placeholder: hook LLM here (OpenAI/Anthropic/etc.)
    # Also can trigger 3D avatar animations / audio generation pipeline
    user_msg = req.message.lower()
    if "recommend" in user_msg or "o que" in user_msg:
        reply = "Posso te mostrar produtos que combinam com seu histórico. Quer ver?"
    else:
        reply = "Olá! Eu sou seu assistente Vyon. Como posso ajudar hoje?"
    return {"reply": reply, "suggestions": []}