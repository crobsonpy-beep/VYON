from flask import Flask, request, jsonify
app = Flask(__name__)

# Simple rule-based recommender: boost same category, higher rating
@app.route('/recommend', methods=['POST'])
def recommend():
    data = request.json or {}
    user_history = data.get('history', [])  # list of product dicts
    catalog = data.get('catalog', [])  # list of product dicts
    # rule: if user recently viewed product with source=X or category=Y, prioritize similar titles
    scores = []
    for p in catalog:
        score = 0.0
        if any(h.get('source') == p.get('source') for h in user_history):
            score += 1.0
        if p.get('rating'):
            score += float(p.get('rating'))/5.0
        # keyword boost if any token in history titles matches
        history_titles = " ".join([h.get('title','') for h in user_history]).lower()
        if any(tok in (p.get('title','').lower()) for tok in history_titles.split()):
            score += 0.5
        scores.append((score, p))
    scores.sort(key=lambda x: x[0], reverse=True)
    recommended = [{"score": s, "product": p} for s,p in scores[:10]]
    return jsonify(recommended)

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=int(__import__('os').environ.get('PORT',8000)))