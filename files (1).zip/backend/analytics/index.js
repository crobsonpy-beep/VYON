const express = require('express');
const bodyParser = require('body-parser');
const { Pool } = require('pg');
const app = express();
app.use(bodyParser.json());

const pool = new Pool({
  host: process.env.PG_HOST || 'localhost',
  user: process.env.POSTGRES_USER || 'vyon',
  password: process.env.POSTGRES_PASSWORD || 'vyonpass',
  database: process.env.POSTGRES_DB || 'vyon'
});

app.post('/event', async (req, res) => {
  const { type, user_id, product_id, session_id, meta } = req.body;
  // Save to analytics_events (simple)
  try{
    await pool.query(
      'INSERT INTO analytics_events(type, user_id, product_id, session_id, meta, created_at) VALUES($1,$2,$3,$4,$5,NOW())',
      [type, user_id, product_id, session_id, JSON.stringify(meta||{})]
    );
    res.json({ ok: true });
  }catch(e){
    console.error(e);
    res.status(500).json({ ok: false, error: e.message });
  }
});

app.listen(process.env.PORT || 7000, ()=>console.log('Analytics on 7000'));