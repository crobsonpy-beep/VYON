const express = require('express');
const bodyParser = require('body-parser');
const Stripe = require('stripe');
const app = express();
app.use(bodyParser.json());
const stripe = Stripe(process.env.STRIPE_SECRET || 'sk_test_xxx');

app.post('/create-intent', async (req, res) => {
  const { amount, currency = 'usd', metadata } = req.body;
  try {
    const intent = await stripe.paymentIntents.create({
      amount,
      currency,
      metadata,
      automatic_payment_methods: { enabled: true }
    });
    res.json({ clientSecret: intent.client_secret });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

app.listen(process.env.PORT||6000, ()=>console.log('Payments on 6000'));