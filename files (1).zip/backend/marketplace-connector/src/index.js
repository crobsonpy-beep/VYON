const express = require('express');
const bodyParser = require('body-parser');
const normalize = require('./normalizer');
const app = express();
app.use(bodyParser.json());

// Example: /search?q=phone
app.get('/search', async (req, res) => {
  const q = req.query.q || '';
  // In prod: call Amazon/MercadoLibre/eBay/Hotmart SDKs or APIs
  // Simulate multi-source results
  const results = [
    { source: 'amazon', product_id: 'A1', title: `Amazon ${q}`, price: 99.99, currency: 'USD', image_url: '' },
    { source: 'ml', product_id: 'M1', title: `MercadoLivre ${q}`, price: 89.9, currency: 'BRL', image_url: '' }
  ];
  const normalized = results.map(normalize);
  res.json(normalized);
});

app.listen(process.env.PORT||5000, ()=>console.log('Marketplace connector on 5000'));