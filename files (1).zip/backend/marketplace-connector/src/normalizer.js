module.exports = function normalize(raw) {
  // Normalize different marketplaces to unified schema
  return {
    source: raw.source,
    product_id: raw.product_id,
    title: raw.title,
    description: raw.description || '',
    price: raw.price,
    currency: raw.currency || 'USD',
    image_url: raw.image_url || '',
    gallery: raw.gallery || [],
    rating: raw.rating || 0,
    affiliate_url: raw.affiliate_url || `https://affiliate.example.com/${raw.source}/${raw.product_id}`
  };
};