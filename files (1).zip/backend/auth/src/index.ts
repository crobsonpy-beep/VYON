import express from 'express';
import jwt from 'jsonwebtoken';
import bodyParser from 'body-parser';
const app = express();
app.use(bodyParser.json());

const JWT_SECRET = process.env.JWT_SECRET || 'changeme';

app.post('/login', async (req, res) => {
  const { email, password } = req.body;
  // NOTE: in prod, validate against DB and hashed password
  if (!email) return res.status(400).send({ error: 'missing email' });
  // Dummy user
  const user = { id: 1, email, role: 'user' };
  const token = jwt.sign({ sub: user.id, email: user.email, role: user.role }, JWT_SECRET, { expiresIn: '7d' });
  res.json({ token, user });
});

app.get('/verify', (req, res) => {
  const auth = req.headers.authorization;
  if (!auth) return res.status(401).send({ ok: false });
  const token = auth.replace('Bearer ', '');
  try {
    const payload = jwt.verify(token, JWT_SECRET);
    res.json({ ok: true, payload });
  } catch (e) {
    res.status(401).send({ ok: false, error: e.message });
  }
});

app.listen(process.env.PORT || 4000, () => console.log('Auth service on 4000'));