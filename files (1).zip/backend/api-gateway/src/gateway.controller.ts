import { Controller, Get, Req, Res, Post, Body } from '@nestjs/common';
import { Request, Response } from 'express';
import axios from 'axios';
@Controller()
export class GatewayController {
  @Get('health')
  health() {
    return { status: 'ok', services: ['auth','marketplace','payments','analytics'] };
  }

  // Proxy example to marketplace service (simple)
  @Get('marketplace/search')
  async search(@Req() req: Request, @Res() res: Response) {
    const params = req.query;
    const url = `${process.env.MARKETPLACE_SERVICE || 'http://localhost:5000'}/search`;
    const r = await axios.get(url, { params });
    return res.json(r.data);
  }

  // Forward analytics events
  @Post('analytics/event')
  async analytics(@Body() body: any) {
    const url = `${process.env.ANALYTICS_SERVICE || 'http://localhost:7000'}/event`;
    const r = await axios.post(url, body);
    return r.data;
  }
}