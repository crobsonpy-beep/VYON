# env.ps1 - generate .env from template
@"
POSTGRES_USER=vyon
POSTGRES_PASSWORD=vyonpass
POSTGRES_DB=vyon
JWT_SECRET=changeme
STRIPE_SECRET=sk_test_xxx
"@ | Out-File -Encoding utf8 .env
Write-Output ".env generated"