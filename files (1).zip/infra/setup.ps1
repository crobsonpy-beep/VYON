# setup.ps1 - checks for docker, docker-compose, git
Write-Output "Checking environment..."
if (-not (Get-Command docker -ErrorAction SilentlyContinue)) {
  Write-Error "Docker not found. Please install Docker Desktop."
  exit 1
}
if (-not (Get-Command docker-compose -ErrorAction SilentlyContinue)) {
  Write-Output "docker-compose not found, but Docker Desktop included compose plugin may be used."
}
Write-Output "Environment OK."