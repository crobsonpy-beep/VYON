```jsx
import axios from 'axios';
import Link from 'next/link';
export default function Home() {
  async function search() {
    const r = await axios.get(`${process.env.NEXT_PUBLIC_API}/marketplace/search?q=phone`);
    // Send analytics
    await axios.post(`${process.env.NEXT_PUBLIC_API}/analytics/event`, { type: 'product_view', meta: { q: 'phone' } });
    console.log(r.data);
  }
  return (
    <div>
      <h1>Vyon Discovery Marketplace (Demo)</h1>
      <button onClick={search}>Buscar demo</button>
      <p><Link href="/product/1">Exemplo de produto (ir)</Link></p>
    </div>
  );
}
```